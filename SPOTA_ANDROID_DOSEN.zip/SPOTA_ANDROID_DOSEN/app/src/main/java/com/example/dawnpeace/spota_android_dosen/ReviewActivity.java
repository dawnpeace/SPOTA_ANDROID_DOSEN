package com.example.dawnpeace.spota_android_dosen;

import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.example.dawnpeace.spota_android_dosen.Model.Review;
import com.example.dawnpeace.spota_android_dosen.RetrofitInterface.ReviewInterface;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ReviewActivity extends AppCompatActivity {

    SharedPrefHelper mSharedPref;
    RecyclerView mRecyclerView;
    FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
//        setReview();
    }

//    public void setReview(){
//        Retrofit retrofit = new Retrofit.Builder().baseUrl(APIUrl.BASE_URL)
//                .client(mSharedPref.getInterceptor())
//                .addConverterFactory(GsonConverterFactory.create())
//                .build();
//
//        ReviewInterface review = retrofit.create(ReviewInterface.class);
//        Call<List<Review>> call = review.getReviews();
//
//        call.enqueue(new Callback<List<Review>>() {
//            @Override
//            public void onResponse(Call<List<Review>> call, Response<List<Review>> response) {
//                if(response.isSuccessful()){
//                    mRecyclerView = findViewById(R.id.rv_review);
//                    ReviewRecyclerAdapter adapter = new ReviewRecyclerAdapter(ReviewActivity.this,response.body());
//                    mRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
//                    mRecyclerView.setAdapter(adapter);
//
//                }
//            }
//
//            @Override
//            public void onFailure(Call<List<Review>> call, Throwable t) {
//                Toast.makeText(ReviewActivity.this, "Telah terjadi kesalahan", Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
}
