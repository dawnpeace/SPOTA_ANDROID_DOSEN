package com.example.dawnpeace.spota_android_dosen;

import android.content.Intent;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.dawnpeace.spota_android_dosen.Model.Draft;
import com.example.dawnpeace.spota_android_dosen.MyRecyclerViewAdapters.DraftViewAdapter;
import com.example.dawnpeace.spota_android_dosen.RetrofitInterface.PraoutlineInterface;

import java.io.UnsupportedEncodingException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class PreoutlineActivity extends AppCompatActivity {
    private TextView tv_title;
    private WebView wv_description;
    private ImageButton btn_review;
    private TextView tv_upvote;
    private TextView tv_downvote;
    private ImageButton ib_upvote;
    private ImageButton ib_downvote;
    private SharedPrefHelper mSharedPref;
    private RecyclerView rv_approval;
    private LinearLayout ll_preoutline;
    private int preoutline_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preoutline);
        getSupportActionBar().setTitle("Praoutline");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mSharedPref = SharedPrefHelper.getInstance(this);

        Intent retriveIntent = getIntent();
        Bundle bundle = retriveIntent.getExtras();

        if(bundle != null){
            preoutline_id = bundle.getInt("preoutline_id");
        } else {
            Toast.makeText(this, "Data tidak ditemukan", Toast.LENGTH_SHORT).show();
            return;
        }

        initView();
        loadData();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.preoutline_sub_menu,menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem item = menu.getItem(1);
        if(mSharedPref.getUser().isMajorheadmaster()){
            item.setVisible(true);
        }
        return true;
    }

    private void initView(){
        tv_title = findViewById(R.id.tv_draft_title);
        wv_description = findViewById(R.id.wv_draft_description);
        if (Build.VERSION.SDK_INT >= 19) {
            wv_description.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }
        else {
            wv_description.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        wv_description.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);

        btn_review =  findViewById(R.id.ib_comment);
        tv_upvote = findViewById(R.id.tv_draft_upvote);
        tv_downvote = findViewById(R.id.tv_draft_downvote);
        ib_upvote = findViewById(R.id.ib_upvote);
        ib_downvote = findViewById(R.id.ib_downvote);
        rv_approval = findViewById(R.id.rv_approvals);
        ll_preoutline = findViewById(R.id.ll_preoutline_draft);
    }

    private void loadData(){
        Retrofit retrofit = new Retrofit.Builder().baseUrl(APIUrl.BASE_URL)
                .client(mSharedPref.getInterceptor())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        PraoutlineInterface praoutline = retrofit.create(PraoutlineInterface.class);
        Call<Draft> call = praoutline.getDraft(1);
        call.enqueue(new Callback<Draft>() {
            @Override
            public void onResponse(Call<Draft> call, Response<Draft> response) {

                if(response.isSuccessful()){
                    if(response.body() != null){
                        try{
                            setView(response.body());
                        } catch (UnsupportedEncodingException e){
                            e.printStackTrace();
                        }
                    }
                } else {
                    Toast.makeText(PreoutlineActivity.this, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Draft> call, Throwable t) {
                Toast.makeText(PreoutlineActivity.this, "asdsadsd", Toast.LENGTH_SHORT).show();
                Log.d("FAILUREMAN", "onFailure: "+t.getMessage());
            }
        });
    }


    private void setView(Draft draft) throws UnsupportedEncodingException {
        String data = draft.getDescription();  // the html data
        WebSettings webSettings = wv_description.getSettings();
        webSettings.setTextZoom(80);
        String base64 = android.util.Base64.encodeToString(data.getBytes("UTF-8"), android.util.Base64.DEFAULT);
        wv_description.loadData(base64, "text/html; charset=utf-8", "base64");
        tv_title.setText(draft.getTitle());
        String upvote_count = String.valueOf(draft.getUpvote_count());
        String downvote_count = String.valueOf(draft.getDownvote_count());
        tv_upvote.setText(upvote_count);
        tv_downvote.setText(downvote_count);

        rv_approval.setLayoutManager(new LinearLayoutManager(this));
        DraftViewAdapter adapter = new DraftViewAdapter(this,draft.getApprovals());
        rv_approval.setAdapter(adapter);
        ll_preoutline.setVisibility(View.VISIBLE);
    }
}
