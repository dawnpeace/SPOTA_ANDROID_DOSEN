package com.example.dawnpeace.spota_android_dosen.TabFragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.dawnpeace.spota_android_dosen.APIUrl;
import com.example.dawnpeace.spota_android_dosen.Model.Praoutline;
import com.example.dawnpeace.spota_android_dosen.MyRecyclerViewAdapters.PraoutlineDraftAdapter;
import com.example.dawnpeace.spota_android_dosen.R;
import com.example.dawnpeace.spota_android_dosen.RetrofitInterface.PraoutlineInterface;
import com.example.dawnpeace.spota_android_dosen.SharedPrefHelper;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ReviewedDraftFragment extends Fragment {
    private RecyclerView rv_reviewed_draft;
    private View mainView;
    private SharedPrefHelper mSharedPref;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mainView = inflater.inflate(R.layout.fragment_reviewed_draft,container,false);
        rv_reviewed_draft = mainView.findViewById(R.id.rv_reviewed_draft);
        mSharedPref = SharedPrefHelper.getInstance(getActivity());
        loadDrafts();
        return mainView;
    }

    private void loadDrafts(){
        Retrofit retrofit = new Retrofit.Builder().baseUrl(APIUrl.BASE_URL)
                .client(mSharedPref.getInterceptor())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        PraoutlineInterface drafts = retrofit.create(PraoutlineInterface.class);
        Call<List<Praoutline>> call = drafts.getReviewedDrafts();
        call.enqueue(new Callback<List<Praoutline>>() {
            @Override
            public void onResponse(Call<List<Praoutline>> call, Response<List<Praoutline>> response) {
                if(response.isSuccessful()){
                    PraoutlineDraftAdapter adapter = new PraoutlineDraftAdapter(getActivity(),response.body());
                    rv_reviewed_draft.setLayoutManager(new LinearLayoutManager(getActivity()));
                    rv_reviewed_draft.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<List<Praoutline>> call, Throwable t) {

            }
        });
    }
}
