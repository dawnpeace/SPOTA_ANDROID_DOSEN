package com.example.dawnpeace.spota_android_dosen.RetrofitInterface;

import com.example.dawnpeace.spota_android_dosen.Model.Draft;
import com.example.dawnpeace.spota_android_dosen.Model.Praoutline;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface PraoutlineInterface {

    @POST("api/dosen/praoutline/daftar-baru")
    Call<List<Praoutline>> getNewDrafts();

    @POST("api/dosen/praoutline/review-saya")
    Call<List<Praoutline>> getReviewedDrafts();

    @POST("api/dosen/praoutline/draft/{id}")
    Call<Draft> getDraft(@Path("id") int id);
}
