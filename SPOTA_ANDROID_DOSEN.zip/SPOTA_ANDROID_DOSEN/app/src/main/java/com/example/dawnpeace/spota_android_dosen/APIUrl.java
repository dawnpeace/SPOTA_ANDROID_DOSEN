package com.example.dawnpeace.spota_android_dosen;

public class APIUrl {
    public static final String BASE_URL = "http://192.168.100.3:8000/";
}
