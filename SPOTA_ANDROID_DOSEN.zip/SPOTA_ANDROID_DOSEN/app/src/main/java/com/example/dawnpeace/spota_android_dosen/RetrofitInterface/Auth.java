package com.example.dawnpeace.spota_android_dosen.RetrofitInterface;

import com.example.dawnpeace.spota_android_dosen.Model.Login;
import com.example.dawnpeace.spota_android_dosen.Model.User;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface Auth {

    @FormUrlEncoded
    @POST("api/auth/login/")
    Call<Login> login(@Field("identity_number") String identity_number, @Field("password") String password);

    @POST("api/auth/me/")
    Call<User> getUser();
}
